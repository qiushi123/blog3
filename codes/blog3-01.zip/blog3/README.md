# 所用技术
- springboot2 项目框架
- es 实现大数据全文搜索
- jpa	实现数据持久化
- bootstrap	html+css+js封装框架，可以快速搭建web页面
- spring security	权限管理，安全服务
