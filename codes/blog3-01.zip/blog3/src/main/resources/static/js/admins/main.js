/**
 * Bolg main JS.
 * Created by waylau.com on 2017/3/9.
 */
"use strict";
//# sourceURL=main.js

// DOM 加载完再执行
$(function() {

	// 搜索
	$(".menu .list-group-item").click(function() {
		console($(this).value);
	});
	

});